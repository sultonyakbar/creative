<?php 
mysql_connect("localhost","root"); //sesuaikan dengan password dan username mysql anda
mysql_select_db("cctv"); //nama database yang kita gunakan
?>
